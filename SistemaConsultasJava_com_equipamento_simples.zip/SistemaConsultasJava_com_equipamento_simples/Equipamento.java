public class Equipamento {
    private String nome;
    private Laboratorio laboratorio;
    private int quantidadeDisponivel;

    public Equipamento(String nome, Laboratorio laboratorio, int quantidadeDisponivel) {
        this.nome = nome;
        this.laboratorio = laboratorio;
        this.quantidadeDisponivel = quantidadeDisponivel;
    }

    public String getNome() {
        return nome;
    }

    public Laboratorio getLaboratorio() {
        return laboratorio;
    }

    public int getQuantidadeDisponivel() {
        return quantidadeDisponivel;
    }
}
