public enum Laboratorio {
    LABORATORIO_1,
    LABORATORIO_2,
    LABORATORIO_3
}
